<footer class="footer">
  <div>
	<span>&copy; 2021 </span>
	<span>Powered by <a href="/">Online CRM</a></span>
  </div>
</footer>