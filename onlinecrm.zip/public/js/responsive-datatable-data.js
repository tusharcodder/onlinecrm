/*Responsive Datatable Init*/

"use strict"; 

$(document).ready(function() {
	$('#myTable1').DataTable( {
		responsive: true
	} );
} );