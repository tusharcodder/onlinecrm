<script src="{{asset('assets/lib/jquery/jquery.min.js')}}"></script>
<script src="{{asset('assets/lib/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
<script src="{{asset('assets/lib/feather-icons/feather.min.js')}}"></script>
<script src="{{asset('assets/lib/perfect-scrollbar/perfect-scrollbar.min.js')}}"></script>
<script src="{{asset('assets/assets/js/dashforge.js')}}"></script> 

<!----> 
<script src="{{asset('assets/lib/datatables.net/js/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('assets/lib/datatables.net-dt/js/dataTables.dataTables.min.js')}}"></script>
<script src="{{asset('assets/lib/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>
<script src="{{asset('assets/lib/datatables.net-responsive-dt/js/responsive.dataTables.min.js')}}"></script>
<script src="{{asset('assets/lib/select2/js/select2.min.js')}}"></script>
<script src="{{asset('assets/lib/raphael/raphael.min.js')}}"></script>
<script src="{{asset('assets/lib/morris.js/morris.min.js')}}"></script>

<script src="{{asset('js/jquery-1.12.4.js')}}"></script> 
<script src="{{asset('js/jquery-ui.js')}}"></script>

<!-- custom js script -->
<script src="{{ asset('js/common.js') }}" defer></script>